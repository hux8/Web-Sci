Name: Xiaowei Hu (Wendy)
RCSID: hux8

Lab 1 -- Tweets Ticker

As shown in the page. I used AJAX to read JSON file of all tweets and to populate the html with all the tweets and 
profile pic&name of the user. Then I used a ticker function to scroll it every 3 seconds. 

I also took out all the tags that are used in the tweets to make a ticker of the tags.