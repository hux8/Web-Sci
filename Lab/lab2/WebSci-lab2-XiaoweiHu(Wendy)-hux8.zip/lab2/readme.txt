Name: Xiaowei Hu (Wendy)
RCSID: hux8

For this lab, I used weather API from OpenWeatherMap and called it with ajax as a JSON 
file (apparently you can call it as an XML file as well). In order to get the location 
of the user, I used Geolocation API of HTML5. After getting the user's Latitude and 
Longitude, I used AJAX and OpenWeatherMap to retrieve the weather at the user's location.
Then I used data in the JSON file to populate my html to include the city name, description
of the current weather, current temperature, wind speed, humidity and a cute icon that
represents the current weather. 